import psycopg2
import time
import socket

DB_CONFIG = {
    "dbname": "ecomdb",
    "user": "ecomuser",
    "password": "yourpass",
    "host": "localhost",
    "port": "5432"
}

TCP_TARGET = ("192.168.1.100", 9999)  # IP:PORT of netcat or backend listener

def fetch_pending_events(conn):
    with conn.cursor() as cur:
        cur.execute("""
            SELECT id, order_id FROM order_event_queue
            WHERE processed = FALSE
            ORDER BY created_at ASC
            LIMIT 10
        """)
        return cur.fetchall()

def mark_processed(conn, event_id):
    with conn.cursor() as cur:
        cur.execute("UPDATE order_event_queue SET processed = TRUE WHERE id = %s", (event_id,))
    conn.commit()

def get_order_item_history(conn, order_id):
    with conn.cursor() as cur:
        cur.execute("""
            SELECT string_agg(
                'product_id=' || oi.product_id || 
                ',product_name=' || p.name ||
                ',quantity=' || oi.quantity ||
                ',item_price=' || oi.price, 
                E'\n')
            FROM Order_Items oi
            JOIN Products p ON p.id = oi.product_id
            WHERE oi.order_id = %s
        """, (order_id,))
        result = cur.fetchone()[0]
        return result or ""

def send_over_tcp(message):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect(TCP_TARGET)
        s.sendall(message.encode())

def main():
    conn = psycopg2.connect(**DB_CONFIG)
    print("🟢 Order Event Listener started.")

    while True:
        try:
            events = fetch_pending_events(conn)
            for event_id, order_id in events:
                print(f"📦 Processing Order ID: {order_id}")
                data = get_order_item_history(conn, order_id)
                if data:
                    send_over_tcp(data)
                    mark_processed(conn, event_id)
        except Exception as e:
            print("❌ Error:", e)

        time.sleep(5)  # poll every 5 seconds

if __name__ == "__main__":
    main()
