#************************************************************************
#* Code Name      : 
#* Author         : 
#* Date           : 00/00/0000 Last Update:  99/99/9999
#* Version        :   0.0.
#* Functional Spec ID: 240-...
#*------------------------- O B J E C T I V E --------------------------*
#*
#*------------------------------- CALLS
#*---------------------------------*
#*    < List all calls from this program here >
#*  FUNCTION:
#*
#*  TRANSACTION: ZZZZ,
#*               AAAA
#*
#*----------------------------------------------------------------------*
#* MODIFICATION HISTORY LOG:
#* Date     Programmer      Correction     Description
#*----------------------------------------------------------------------*
#*00/00/00  Name Surname    AAAA999999     Description
#*----------------------------------------------------------------------*
#************************************************************************
# helper.py
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import socket

HOST_NAME = '127.0.0.1'
PORT = 8001
NC_HOST = '127.0.0.1'
NC_PORT = 9999

class IPCHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/ipc":
            self.send_response(404)
            self.end_headers()
            return

        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)

        try:
            payload = json.loads(post_data)
            items = payload.get("items", [])

            print(f"Received items: {items}")

            # Send to Netcat listener via TCP
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((NC_HOST, NC_PORT))
                s.sendall(("\n".join(items) + "\n").encode("utf-8"))

            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"status": "ok", "count": len(items)}).encode('utf-8'))

        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))

def run():
    server = HTTPServer((HOST_NAME, PORT), IPCHandler)
    print(f"[IPC Server] Running at http://{HOST_NAME}:{PORT}/ipc")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[IPC Server] Shutting down.")
        server.server_close()

if __name__ == "__main__":
    run()
